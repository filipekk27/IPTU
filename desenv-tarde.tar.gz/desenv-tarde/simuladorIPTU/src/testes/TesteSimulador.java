package testes;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import calculo.Simulador;

public class TesteSimulador extends Simulador{
	
private Simulador simulador;

@Before
public void setUp() throws Exception {
this.simulador= new Simulador();
}

@Test
public void testeSimulador() {
		
double teste1=this.simulador.calcularIPTU("1",180000,0);
double valorEsperado1= 1164.55;
assertEquals(valorEsperado1,teste1,1);
		
double teste2=this.simulador.calcularIPTU("3", 430000, 0);
double valorEsperado2= 6881.90;
assertEquals(valorEsperado2,teste2,1);

double teste3=this.simulador.calcularIPTU("2", 0, 0);
double valorEsperado3=0;
assertEquals(valorEsperado3,teste3,1);

double teste4=this.simulador.calcularIPTU("1", 15000, 0);
double valorEsperado4=572.70;
assertEquals(valorEsperado4,teste4,1);

//Não esta subtraindo desconto
double teste5=this.simulador.calcularIPTU("1", 180000, 200);
double valorEsperado5=1164.55;
assertEquals(valorEsperado5,teste5,1);


		
	}

}
